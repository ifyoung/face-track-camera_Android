package face.camera.beans.record.other;

/**
 * Created by why8222 on 2016/2/25.
 */
public enum MagicFilterType {
    NONE,
    WARM,
    ANTIQUE,
    COOL,
    BRANNAN,
    FREUD,
    HEFE,
    HUDSON,
    INKWELL,
    N1977,
    NASHVILLE,
}
