package face.camera.beans.arc.util.face;

public class RequestLivenessStatus {
    public static final int ANALYZING = 10;
}
